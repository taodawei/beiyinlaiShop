<?php

require_once("YopRsaClient.php");

class YopClient3 extends YopRsaClient
{

}
